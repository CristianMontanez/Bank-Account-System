import java.util.ArrayList;

public class InvoiceSystem {

	protected double monthlyRent ; 
	protected double waterBill ;
	protected double energyRent ;
	protected double carBill ;
	protected double internetBill;
	
	
	
	protected String invoiceID;



	public double getMonthlyRent() {
		return monthlyRent;
	}



	public void setMonthlyRent(double monthlyRent) {
		this.monthlyRent = monthlyRent;
	}



	public double getWaterBill() {
		return waterBill;
	}



	public void setWaterBill(double waterBill) {
		this.waterBill = waterBill;
	}



	public double getEnergyRent() {
		return energyRent;
	}



	public void setEnergyRent(double energyRent) {
		this.energyRent = energyRent;
	}



	public double getCarBill() {
		return carBill;
	}



	public void setCarBill(double carBill) {
		this.carBill = carBill;
	}



	public double getInternetBill() {
		return internetBill;
	}



	public void setInternetBill(double internetBill) {
		this.internetBill = internetBill;
	}



	public String getInvoiceID() {
		return invoiceID;
	}



	public void setInvoiceID(String invoiceID) {
		this.invoiceID = invoiceID;
	}
	
	
	public InvoiceSystem () {
		
	}
	
	public InvoiceSystem(double monthlyRent, double waterBill, double energyRent, double carBill, double internetBill,
			String invoiceID) {
		
		this.monthlyRent = monthlyRent;
		this.waterBill = waterBill;
		this.energyRent = energyRent;
		this.carBill = carBill;
		this.internetBill = internetBill;
		this.invoiceID = invoiceID;
	}




	

	
}
