
public class InvoiceHub {

}
