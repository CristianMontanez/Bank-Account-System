import java.util.*;

public class Customer {

  private String firstName ; 
  private String lastName ;
  private String myAge ;
  
  
  
  //Setters & getters for firstName, lastName & myAge variables
  public String getFirstName() 
  {
	  return firstName;
  }
  
  public void setFirstName(String fn) 
  {
	  this.firstName = fn;
  }

  
  public String getLastName() 
  {
	  return lastName;
  }
  
  public void setLastName(String ln) 
  {
	  this.lastName = ln;
  }

  
  public String getMyage() 
  {
	  return myAge;
  }
  
  public void setMyAge(String ma) 
  {
	  this.lastName = ma;
  }

// End of setters & getters for respected varibles. 
  
  
  

  public String getCustomerInfo(String firstname , String lastname , String myage) 
  {
	  this.firstName = firstname;
	  this.lastName = lastname;
	  this.myAge = myage;
	return firstName + lastName + myAge;
  }

public Customer() {
}
    
 
    
    
    
  
    
	
}
